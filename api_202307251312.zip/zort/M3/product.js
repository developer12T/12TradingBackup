const express = require('express');
const router = express.Router();
const { Op } = require('sequelize');
const { Order,OrderDetail } = require('../db_orm/order/Order') ;
const { Customer } = require('../db_orm/order/Customer') ;
const { Product } = require('../db_orm/product/product') ;

router.post('/getProduct2', async (req, res) => {
    const data = await Product.findAll() ;
    res.json(data);


})


module.exports = router;  