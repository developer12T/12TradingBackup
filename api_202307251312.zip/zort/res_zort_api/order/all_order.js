const axios = require('axios'); 
const orderDataAll = async (req,res) => {
  try {
    const response = await axios.get('https://open-api.zortout.com/v4/Order/GetOrders', {
        headers: {
          storename: 'komsanyuyu@gmail.com',
          apikey: '8Z9AHBBGp6CAaatoLt/Ak3KNSxonZRLEUB6mnS3Ms=',
          apisecret: '7vIqXP7kL3XLAa1sGfD5I2iFgLP8H2ov26QC1NSKy2c=',
        },
      });
  
  //    res.json(response.data);
    return response.data;
  } catch (error) {
    console.error(error);
    res.json({ error: 'Internal server error' });
  }
};

module.exports = orderDataAll;