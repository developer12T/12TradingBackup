const { connectM3,mssql,sequelize,DataTypes } = require('../config/dbconnect');

const Stock = sequelize.define('MITLOC', {
    MLWHLO: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    MLITNO: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    MLBANO: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    MLSTQT: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    MLALQT: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
  },{freezeTableName:true,timestamps:false,createdAt:false,updatedAt:false,primaryKey:false});

const stockERP = async() => {
    const pool = await mssql.connect(connectM3);
    const request = pool.request();
    const query = `SELECT MLWHLO,MLITNO,MLBANO,MLSTQT,MLALQT FROM [MVXJDTA].[MITLOC] `;
    try {
      const results = await request.query(query, {
        type: sequelize.QueryTypes.SELECT,
        model: Stock,
        mapToModel: true,
      });
  
      return results;
    } catch (error) {
      console.error(error);
    }
  };

const getStockM3 = async() => {
    const pool = await mssql.connect(connectM3);
    const request = pool.request();
    const results = await request.query(`SELECT MLWHLO,MLITNO,MLBANO,MLSTQT,MLALQT FROM [MVXJDTA].[MITLOC] WHERE MLITNO = '10010101002' `);
    
    return results;
  }


module.exports = {
    Stock,
    stockERP,
    getStockM3,
};