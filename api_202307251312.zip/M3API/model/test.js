const { connectM3,mssql,sequelize,DataTypes } = require('../config/dbconnect');

const StockTest = sequelize.define('MITLOC', {
    MLWHLO: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    MLITNO: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    MLBANO: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    MLSTQT: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    MLALQT: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
  },{freezeTableName:true,timestamps:false,createdAt:false,updatedAt:false});

//   const stockERP1 = async() => {
//     const pool = await mssql.connect(connectM3);
//     const request = pool.request();
//     const query = `SELECT MLWHLO,MLITNO,MLBANO,MLSTQT,MLALQT FROM [MVXJDTA].[MITLOC] `;
//     try {
//       const results = await request.query(query, {
//         type: sequelize.QueryTypes.SELECT,
//         model: StockTest,
//         mapToModel: true,
//       });
  
//       return results;
//     } catch (error) {
//       console.error(error);
//     }
//   };

// sequelize.sync({force:false,alter:false})
module.exports = {
    StockTest,
    // stockERP1,
};